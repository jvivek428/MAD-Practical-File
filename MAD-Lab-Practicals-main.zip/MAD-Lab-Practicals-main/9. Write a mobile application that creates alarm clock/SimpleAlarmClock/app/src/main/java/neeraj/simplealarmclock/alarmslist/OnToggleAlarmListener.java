package neeraj.simplealarmclock.alarmslist;

import neeraj.simplealarmclock.data.Alarm;

public interface OnToggleAlarmListener {
    void onToggle(Alarm alarm);
}
